import java.io.*;
import java.util.Scanner;

public class FilterRanks {
    public static void main(String[] args) {
        // absolute path for the input file
        String inputFile = "/Users/jaogeronimo/Downloads/FilterRanks/src/data.csv";

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the rank you want to filter: ");
            int targetRank = scanner.nextInt();

            String header = br.readLine();
            if (header != null) {
                System.out.println(header);
            }

            String line;
            boolean found = false;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",");


                String rankStr = columns[columns.length - 1];
                try {
                    int rank = Integer.parseInt(rankStr.trim());


                    if (rank == targetRank) {
                        System.out.println(line);
                        found = true;
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Invalid rank: " + rankStr);
                }
            }

            if (!found) {
                System.out.println("No rows found for rank " + targetRank);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
